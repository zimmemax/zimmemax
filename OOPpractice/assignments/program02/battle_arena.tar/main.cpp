#include <iostream>
#include "pokemon.h"
#include "charmander.h"
#include "bulbasaur.h"
#include "squirtle.h"
#include "trainer.h"
#include "arena.h"
/******************************************************
** Program: battle_arena.cpp
** Author: Max Zimmer
** Date: 10/31/2021
** Description: USER BATTLES  CPU WITH SELECTED POEKMON UNTIL ONE RUNS OUT OF HEALTH  
** Input: USER INPUTS
** Output: THE WINNER
******************************************************/

int main()
{
//Happy with my amount of lines in main? :)

    Arena a;
    a.game();
}